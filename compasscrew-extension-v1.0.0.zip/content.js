function g(e){const t=e.startsWith("http://")&&!e.startsWith("https://"),n=document.querySelectorAll("form");let o=!1,r=!1,c=!1;n.forEach(m=>{m.querySelectorAll("input").forEach(s=>{const i=s.type.toLowerCase(),l=(s.name||"").toLowerCase(),p=(s.autocomplete||"").toLowerCase(),f=(s.placeholder||"").toLowerCase();i==="password"&&(o=!0),(i==="text"||i==="tel"||i==="number")&&(/card|credit|ccn|cc_number|payment/i.test(l)||/card|credit|ccn/i.test(p)||/card number|credit card/i.test(f))&&(r=!0),/login|signin|username|email|user/i.test(l)&&(c=!0)})});let d=null;return(o||r||c)&&t?d="Warning: You are about to enter sensitive information on an unencrypted (HTTP) connection. This data could be intercepted.":(o||r)&&(d=null),{hasPasswordFields:o,hasCreditCardFields:r,hasLoginForm:c,isHTTP:t,formCount:n.length,warning:d}}function h(e){var n;if(document.getElementById("compasscrew-warning"))return;const t=document.createElement("div");t.id="compasscrew-warning",t.innerHTML=`
    <div style="
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      z-index: 2147483647;
      background: linear-gradient(135deg, #dc2626, #b91c1c);
      color: white;
      padding: 12px 20px;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      font-size: 14px;
      display: flex;
      align-items: center;
      gap: 10px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    ">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
        <line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>
      </svg>
      <span style="flex:1"><strong>CompassCrew:</strong> ${e}</span>
      <button id="compasscrew-dismiss" style="
        background: rgba(255,255,255,0.2);
        border: none;
        color: white;
        padding: 4px 8px;
        border-radius: 4px;
        cursor: pointer;
        font-size: 12px;
      ">Dismiss</button>
    </div>
  `,document.body.prepend(t),(n=document.getElementById("compasscrew-dismiss"))==null||n.addEventListener("click",()=>{t.remove()})}let a=window.location.href;function u(){try{const e=g(a);e.warning&&h(e.warning)}catch{}}chrome.runtime.onMessage.addListener(e=>{e.type==="HEADERS_COLLECTED"&&e.url});u();const w=new MutationObserver(()=>{window.location.href!==a&&(a=window.location.href,u())});w.observe(document.body||document.documentElement,{childList:!0,subtree:!0});console.log("CompassCrew content script loaded.");
